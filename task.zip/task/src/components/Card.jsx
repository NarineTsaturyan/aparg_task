export default function Card({ imageTag, imageUrl, imageTitle }) {
  return (
    <div className="col s6 m3 p2">
      <div className="card">
        <div className="card-image">
          <img src={imageUrl} alt="" />
          {/* <span className="card-title">{imageTitle}</span> */}
        </div>
      </div>
    </div>
  );
}
