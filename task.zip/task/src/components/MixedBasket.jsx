import Card from "./Card";
import getImageFromFlickr from "../api/getImageFromFlickr";
import { Draggable, Droppable } from "react-beautiful-dnd";

export default function MixedBasket({ images }) {
  return (
    <div className="mixed-basket">
      <Droppable droppableId="mixedBasket">
        {(provided) => (
          <div ref={provided.innerRef} {...provided.droppableProps}>
            {images.map(
              (
                { id: photoId, secret, server: serverId, farm, title },
                index
              ) => (
                <Draggable key={photoId} draggableId={photoId} index={index}>
                  {(provided) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      {...provided.dragHandleProps}
                    >
                      <Card
                        imageUrl={getImageFromFlickr({
                          farm,
                          secret,
                          serverId,
                          photoId
                        })}
                        imageTag="cat"
                        imageTitle={title}
                      />
                    </div>
                  )}
                </Draggable>
              )
            )}
            {provided.placeholder}
          </div>
        )}
      </Droppable>
    </div>
  );
}
