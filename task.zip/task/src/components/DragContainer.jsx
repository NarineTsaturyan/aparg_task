import Card from "./Card";
import getImageFromFlickr from "../api/getImageFromFlickr";

import { Droppable } from "react-beautiful-dnd";

export default function DragContainer({ droppableId, images }) {
  return (
    <div className="drop-container z-depth-3">
      <h4>{droppableId}</h4>
      <Droppable droppableId={droppableId}>
        {(provided) => (
          <div
            style={{ height: 180 }}
            ref={provided.innerRef}
            {...provided.droppableProps}
          >
            {images.map(
              ({ id: photoId, secret, server: serverId, farm, title }) => (
                <Card
                  key={photoId}
                  imageUrl={getImageFromFlickr({
                    farm,
                    secret,
                    serverId,
                    photoId
                  })}
                  imageTag={droppableId}
                  imageTitle={title}
                />
              )
            )}
            {provided.placeholder}
          </div>
        )}
      </Droppable>
    </div>
  );
}
