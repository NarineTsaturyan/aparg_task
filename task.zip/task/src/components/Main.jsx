import useImages from "../hooks/useImages";
import MixedBasket from "./MixedBasket";
import { DragDropContext } from "react-beautiful-dnd";
import DragContainer from "./DragContainer";
import Spinner from "./Spinner";

export default function Main() {
  const { loading, images, moveImage } = useImages();

  const handleDragEnd = ({ source, destination }) => {
    console.log(source, destination);
    if (!destination) return;

    if (
      destination.droppableId === "mixedBasket" ||
      destination.droppableId === source.droppableId
    )
      return;

    moveImage({
      fromIndex: source.index,
      toIndex: destination.index,
      from: source.droppableId,
      to: destination.droppableId
    });
  };

  if (loading) return <Spinner />;

  return (
    <DragDropContext onDragEnd={handleDragEnd}>
      <div className="row">
        <DragContainer droppableId="cat" images={images.cat} />
      </div>
      <div className="row">
        <DragContainer droppableId="dog" images={images.dog} />
      </div>
      <div className="row">
        <MixedBasket images={images.mixedBasket} />
      </div>
    </DragDropContext>
  );
}
