import Main from "./components/Main";
import "./styles.css";

export default function App() {
  return (
    <div className="container">
      <h2 className="center">Flickr Dragger</h2>
      <Main />
    </div>
  );
}
