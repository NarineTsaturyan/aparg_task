export default async function getImagesByKeyword(keyword) {
  const response = await fetch(
    `https://api.flickr.com/services/rest?method=flickr.photos.search&api_key=0def7c9b732174eccb6c654b222aa909&format=json&tags=${keyword}&nojsoncallback=1`
  );

  return response.json();
}
