export default function getImageFromFlickr({
  farm,
  serverId,
  photoId,
  secret
}) {
  return `https://farm${farm}.staticflickr.com/${serverId}/${photoId}_${secret}.jpg`;
}
