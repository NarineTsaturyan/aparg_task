export default function setCategory(images, category) {
  return images.map((img) => ({ ...img, category }));
}
