import { useCallback, useEffect, useState } from "react";
import getImagesByKeyword from "../api/getImagesByKeyword";
import setCategory from "../utils/setCategory";

const useImages = () => {
  const [loading, setLoading] = useState(false);
  const [images, setImages] = useState({
    mixedBasket: [],
    cat: [],
    dog: []
  });
  const [error, setError] = useState(null);

  const moveImage = ({ fromIndex, toIndex, from, to }) => {
    if (!["cat", "dog"].includes(to)) {
      throw new Error("var to must be either 'cat' or dog");
    }

    const fromClone = [...images[from]];
    const toClone = [...images[to]];
    const [removedImage] = fromClone.splice(fromIndex, 1);

    if (removedImage.category !== to)
      return alert(`You cant move this image to "${to}"`);

    toClone.splice(toIndex, 0, removedImage);

    setImages((p) => ({ ...p, [from]: fromClone, [to]: toClone }));
  };

  const fetchImages = useCallback(async () => {
    try {
      setLoading(true);
      // const { photos } = await getImagesByKeyword(tagList);
      const [{ photos: dogs }, { photos: cats }] = await Promise.all([
        getImagesByKeyword("dog"),
        getImagesByKeyword("cat")
      ]);

      setImages((p) => ({
        ...p,
        mixedBasket: [
          ...setCategory(dogs.photo.slice(1, 6), "dog"),
          ...setCategory(cats.photo.slice(1, 6), "cat")
        ]
      }));
    } catch (e) {
      setError(e.message || "An error occured.");
      console.trace(e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchImages();
  }, [fetchImages]);

  return { images, loading, error, moveImage };
};

export default useImages;
